# PromptShift Master Rules & AI Agent Prompts Vault (v1.0 Production)
Copyright (c) 2026 PromptShift (https://promptshift.dev)

Ce pack contient 50+ règles d'or et directives expertes de production pour :
- Cursor IDE (.cursorrules & .cursor/rules/*.mdc)
- Anthropic Claude Code & Projects (CLAUDE.md)
- GitHub Copilot (.github/copilot-instructions.md)
- Windsurf Cascade (.windsurfrules)
- Google Gemini CLI & Antigravity (GEMINI.md, AGENTS.md)

## Installation Rapide :
1. Copiez les fichiers souhaités dans votre dépôt.
2. Synchronisez automatiquement vos règles avec le CLI PromptShift :
   ```bash
   npx promptshift --watch
   ```
