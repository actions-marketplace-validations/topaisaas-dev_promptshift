# Rust & Tokio Async Standards
- Never use unwrap() or expect() in production code paths; use Result<T, E> and '?' operator.
- Use thiserror for domain errors and anyhow for application entry points.
- Structure concurrency around tokio::spawn and tokio::select! with cancellation safety.
- Keep lock guard scopes as short as possible; never hold a Mutex across an .await point.
