# Python FastAPI & Pydantic v2 Production Directives
- Use strict Pydantic v2 schemas for all request payloads and response models.
- Implement dependency injection via FastAPI Depends() for database sessions, auth, and clients.
- Use asynchronous route handlers (async def) for non-blocking I/O operations.
- Handle exceptions with custom HTTPException classes and global exception handlers.
- Enforce strict typing with mypy and type annotations on every function signature.
