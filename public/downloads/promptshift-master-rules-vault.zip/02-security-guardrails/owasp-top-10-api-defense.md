# OWASP API Security Top 10 Guidelines
- Implement strict rate limiting on authentication, payment, and sensitive API endpoints.
- Validate and sanitize all inputs at boundary layers using schemas (Zod, Pydantic).
- Set secure HTTP headers: Content-Security-Policy, X-Frame-Options: DENY, Strict-Transport-Security.
- Never expose internal database stack traces or raw ORM errors in API error responses.
