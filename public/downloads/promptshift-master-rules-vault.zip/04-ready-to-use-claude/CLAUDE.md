# PromptShift Universal CLAUDE.md Master Rules
- Stack: Next.js 15 App Router, TypeScript Strict, TailwindCSS.
- Workflow: Run 'npm test' or equivalent before finishing turn.
- Security: Zero-retention RAM architecture, IDOR checks, CSRF protection.
- Monetization: Polar.sh MoR integration for frictionless Apple Pay / Google Pay.
- CLI Sync: Use 'npx promptshift --watch' for bidirectional rules sync.
