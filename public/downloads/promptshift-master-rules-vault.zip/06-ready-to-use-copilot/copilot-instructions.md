# GitHub Copilot Repository Instructions
- Maintain TypeScript strictness across all modules.
- Ensure all exported functions have complete JSDoc descriptions.
- Validate all user-facing forms with Zod before submission.
- Ensure all interactive buttons have explicit accessible aria-label attributes.
