# Anti-Hallucination & Ground-Truth Verification
- Before asserting a fact, verify it against the actual repository files or live command outputs.
- In financial or metric calculations, use exact ground-truth data from the source of truth.
- When an API or library method is uncertain, inspect the official schema or type definitions.
