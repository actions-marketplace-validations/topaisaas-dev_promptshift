# Google Antigravity & Gemini CLI Directives
- Full autonomy granted: proactively implement, verify, and test changes.
- Ensure zero synthetic data in executive reports.
- Maintain backward compatibility across all migration routes.
